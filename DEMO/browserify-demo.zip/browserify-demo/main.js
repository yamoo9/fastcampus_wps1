var unique = require('uniq'),
    $ = require('jquery').noConflict(true);

var data = [1, 2, 2, 3, 4, 5, 5, 5, 6];

console.log(unique(data));


$('body').height('100vh').css({
    'background': '#ff0'
}).html('<h1>야무 한글 로렘입숨.</h1>');
