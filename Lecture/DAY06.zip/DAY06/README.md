###### Front-End
## DOM + Javascript

### 진행

1. Javascript 문법 정리
1. Client 환경의 Javascript와 문서객체모델(DOM)
1. DOM + Javascript
1. jQuery

### 레퍼런스
- [[번역] 탁월한 프론트엔드 엔지니어가 되는 법](http://hyunseob.github.io/2016/02/21/how-to-become-a-great-frontend-engineer/)
- [Javascript: 세상에서 제일 잘못 이해되고 있는 언어 by Douglas Crokford](http://vandbt.tistory.com/36)
- [MDN 개발자를 위한 웹 기술: Javascript](https://developer.mozilla.org/ko/docs/Web/JavaScript)
- [Eloquent Javascript](http://eloquentjavascript.net/)
- [JavaScript Garden](http://bonsaiden.github.io/JavaScript-Garden/ko/)