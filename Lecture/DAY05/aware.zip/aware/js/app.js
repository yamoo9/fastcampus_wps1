/**
 * --------------------------------
 * 그리드시스템 가이드라인 드로잉
 * --------------------------------
 */
toggleGrid('.container', 'grid');

/**
 * --------------------------------
 * <html> 요소의 class 속성 값을
 * Javascript 지원되는 환경이면
 * 'js'로 변경.
 * --------------------------------
 */
// debugger;
document.querySelector('html').setAttribute('class', 'js');
